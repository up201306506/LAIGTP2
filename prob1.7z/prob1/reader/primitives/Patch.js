/**
 * Construtor da clasee Patch 
 * 
 * @param scene	O objecto CGFscene em que vai ser apresentado o Patch
 * @param order A ordem das curvas em AMBOS os UV. Pode ser 1, 2 ou 3. 
 * @param partsU Numero de partes (vertices - 1) que vão ser usados no sentido U 
 * @param partsV Numero de partes (vertices - 1) que vão ser usados no sentido V 
 * @param controlpoints Lista com listas de pontos que em cada U->V indicam onde se encontram os pontos de controlo do patch em XYZ. 
 * @see #makeSurface(order,partsU,partsV,controlpoints)
 */
 
 //LAIGPROB1_inicio
function Patch(scene, orderU, orderV ,partsU,partsV,controlpoints) {//LAIGPROB1_fim;
	this.scene = scene;
 	CGFobject.call(this,scene);
    this.surface;
    this.ready=false;
	//LAIGPROB1_inicio
    this.makeSurface(orderU, orderV,partsU,partsV,controlpoints);//LAIGPROB1_fim;
    this.initBuffers();
 };

 Patch.prototype = Object.create(CGFobject.prototype);
 Patch.prototype.constructor = Patch;

/**
 * Forma e guarda em this.surface um objecto CGFnurbsSurface 
 * 
 * @param order A ordem das curvas em AMBOS os UV. Pode ser 1, 2 ou 3. 
 * @param partsU Numero de partes (vertices - 1) que vão ser usados no sentido U 
 * @param partsV Numero de partes (vertices - 1) que vão ser usados no sentido V 
 * @param controlpoints Lista com listas de pontos que em cada U->V indicam onde se encontram os pontos de controlo do patch em XYZ.
 */
 
 //LAIGPROB1_inicio
Patch.prototype.makeSurface = function (orderU, orderV,partsU,partsV,controlpoints) {
		
	var nurbsSurface;

	for (var i = 0; i < controlpoints.length; i++)
	{
		controlpoints[i].push(1);
	}
	
	var newControlPoints = []; 
	var point = 0; 
	var knotsU = []; var knotsV = [];
	for (var u = 0; u <= orderU; u++)
	{
		newControlPoints[u] = [];
		for (var v = 0; v <= orderV; v++)
		{
			newControlPoints[u][v] = controlpoints[point];
			point++;
		}
	}	
	
	for (var u = 0; u <= orderU; u++) knotsU.push(0);
	for (var u = 0; u <= orderU; u++) knotsU.push(1);
	for (var v = 0; v <= orderV; v++) knotsV.push(0);
	for (var v = 0; v <= orderV; v++) knotsV.push(1);
	
	
	nurbsSurface = new CGFnurbsSurface(orderU, orderV,knotsU, knotsV, newControlPoints);
	

	getSurfacePoint = function(u, v) {
		return nurbsSurface.getPoint(u, v);
	};

	this.surface = new CGFnurbsObject(this.scene, getSurfacePoint, partsU, partsV );
	this.ready = true;


};
//LAIGPROB1_fim;


//LAIGPROB1_incio;
 Patch.prototype.initBuffers = function() {
	this.surface.primitiveType = this.scene.gl.LINES;
	this.surface.initGLBuffers();
};
//LAIGPROB1_fim;

/**
 * Mostra a superficie na cena 
 * 
 */
Patch.prototype.display= function()
{
	if(this.ready)
	{
		//console.log("display");
		//var transform = mat4.create();
		//mat4.scale(transform, transform, [1,1,1]);
		//this.scene.multMatrix(transform);
		this.surface.display();
	}
		
		
};